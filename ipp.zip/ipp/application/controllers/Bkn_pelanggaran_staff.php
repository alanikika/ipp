<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_pelanggaran_staff extends CI_Controller
{


    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_pelanggaran_staff_model');
        $this->load->model('Bkn_staff_biro_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if(!isset($_GET['biro_nama']) || $_GET['biro_nama'] == '')
        {
            //$bkn_pelanggar = $this->Bkn_pelanggaran_staff_model->get_all_query();
            $bkn_pelanggaran_staff = $this->Bkn_pelanggaran_staff_model->get_bobot_semua();
            $bkn_rata_pelanggaran = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran_semua();
            
        }
        else 
        {
            $biron = $_GET['biro_nama'];  
            $bkn_pelanggaran_staff = $this->Bkn_pelanggaran_staff_model->get_bobot_biro($biron);
            $bkn_rata_pelanggaran = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran_biro($biron);
        }
        $staff_by_biro = $this->Bkn_staff_biro_model->get_biro();
        
       // $bkn_rata_pelanggaran = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran();


        $data = array(
            'bkn_pelanggaran_staff_data' => $bkn_pelanggaran_staff,
            'biro' => $staff_by_biro,
            'rata_pelanggaran' => $bkn_rata_pelanggaran
            );

        $this->template->load('template','bkn_pelanggaran_staff/bkn_pelanggaran_staff_list', $data);
    }

    public function read($nip) 
    {
        $row = $this->Bkn_pelanggaran_staff_model->get_by_id($nip);
        if ($row) {
            $data = array(
              /*'id' => $row->id,
              'id_pelanggaran' => $row->id_pelanggaran,
              'nip' => $row->nip,*/
              'pelanggaran' => $row
              );
            $this->template->load('template','bkn_pelanggaran_staff/bkn_pelanggaran_staff_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pelanggaran_staff'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_pelanggaran_staff/create_action'),
            'id' => set_value('id'),
            'id_pelanggaran' => set_value('id_pelanggaran'),
            'nip' => set_value('nip'),
            );
        $this->template->load('template','bkn_pelanggaran_staff/bkn_pelanggaran_staff_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
              'id_pelanggaran' => $this->input->post('id_pelanggaran',TRUE),
              'nip' => $this->input->post('nip',TRUE),
              );

            $this->Bkn_pelanggaran_staff_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bkn_pelanggaran_staff'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Bkn_pelanggaran_staff_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bkn_pelanggaran_staff/update_action'),
                'id' => set_value('id', $row->id),
                'id_pelanggaran' => set_value('id_pelanggaran', $row->id_pelanggaran),
                'nip' => set_value('nip', $row->nip),
                );
            $this->template->load('template','bkn_pelanggaran_staff/bkn_pelanggaran_staff_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pelanggaran_staff'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
              'id_pelanggaran' => $this->input->post('id_pelanggaran',TRUE),
              'nip' => $this->input->post('nip',TRUE),
              );

            $this->Bkn_pelanggaran_staff_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_pelanggaran_staff'));
        }
    }
    
    public function delete($id) 
    {
        $this->Bkn_pelanggaran_staff_model->delete($id);
        redirect(site_url('bkn_pelanggaran_staff'));

        /*if ($row) {
            $this->Bkn_pelanggaran_staff_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_pelanggaran_staff'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pelanggaran_staff'));
        }*/
    }

    public function _rules() 
    {
       $this->form_validation->set_rules('id_pelanggaran', 'id pelanggaran', 'trim|required');
       $this->form_validation->set_rules('nip', 'nip', 'trim|required');

       $this->form_validation->set_rules('id', 'id', 'trim');
       $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
   }

   public function excel()
   {
    $this->load->helper('exportexcel');
    $namaFile = "bkn_pelanggaran_staff.xls";
    $judul = "bkn_pelanggaran_staff";
    $tablehead = 0;
    $tablebody = 1;
    $nourut = 1;
        //penulisan header
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment;filename=" . $namaFile . "");
    header("Content-Transfer-Encoding: binary ");

    xlsBOF();

    $kolomhead = 0;
    xlsWriteLabel($tablehead, $kolomhead++, "No");
    xlsWriteLabel($tablehead, $kolomhead++, "Id Pelanggaran");
    xlsWriteLabel($tablehead, $kolomhead++, "Nip");

    foreach ($this->Bkn_pelanggaran_staff_model->get_all() as $data) {
        $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
        xlsWriteNumber($tablebody, $kolombody++, $nourut);
        xlsWriteNumber($tablebody, $kolombody++, $data->id_pelanggaran);
        xlsWriteLabel($tablebody, $kolombody++, $data->nip);

        $tablebody++;
        $nourut++;
    }

    xlsEOF();
    exit();
}

public function word()
{
    header("Content-type: application/vnd.ms-word");
    header("Content-Disposition: attachment;Filename=bkn_pelanggaran_staff.doc");

    $data = array(
        'bkn_pelanggaran_staff_data' => $this->Bkn_pelanggaran_staff_model->get_all(),
        'start' => 0
        );

    $this->load->view('bkn_pelanggaran_staff_doc',$data);
}

}
