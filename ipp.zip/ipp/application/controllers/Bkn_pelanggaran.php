<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_pelanggaran extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_pelanggaran_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bkn_pelanggaran = $this->Bkn_pelanggaran_model->get_all();

        $data = array(
            'bkn_pelanggaran_data' => $bkn_pelanggaran
            );

        $this->template->load('template','bkn_pelanggaran/bkn_pelanggaran_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Bkn_pelanggaran_model->get_by_id($id);
        if ($row) {
            $data = array(
              'id_pelanggaran' => $row->id_pelanggaran,
              'jenis_pelanggaran' => $row->jenis_pelanggaran,
              'bobot_nilai' => $row->bobot_nilai,
              );
            $this->template->load('template','bkn_pelanggaran/bkn_pelanggaran_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pelanggaran'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_pelanggaran/create_action'),
            'id_pelanggaran' => set_value('id_pelanggaran'),
            'jenis_pelanggaran' => set_value('jenis_pelanggaran'),
            'bobot_nilai' => set_value('bobot_nilai'),
            );
        $this->template->load('template','bkn_pelanggaran/bkn_pelanggaran_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
                'id_pelanggaran' => $this->input->post('id_pelanggaran', TRUE),
                'jenis_pelanggaran' => $this->input->post('jenis_pelanggaran',TRUE),
                'bobot_nilai' => $this->input->post('bobot_nilai',TRUE),
              );

            $this->Bkn_pelanggaran_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bkn_pelanggaran'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Bkn_pelanggaran_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bkn_pelanggaran/update_action'),
                'id_pelanggaran' => set_value('id_pelanggaran', $row->id_pelanggaran),
                'jenis_pelanggaran' => set_value('jenis_pelanggaran', $row->jenis_pelanggaran),
                'bobot_nilai' => set_value('bobot_nilai', $row->bobot_nilai),
                );
            $this->template->load('template','bkn_pelanggaran/bkn_pelanggaran_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pelanggaran'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_pelanggaran', TRUE));
        } else {
            $data = array(
                'id_pelanggaran' => $this->input->post('id_pelanggaran',TRUE), 
                'jenis_pelanggaran' => $this->input->post('jenis_pelanggaran',TRUE),
                'bobot_nilai' => $this->input->post('bobot_nilai',TRUE),
              );

            $this->Bkn_pelanggaran_model->update($this->input->post('id_pelanggaran', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_pelanggaran'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bkn_pelanggaran_model->get_by_id($id);

        if ($row) {
            $this->Bkn_pelanggaran_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_pelanggaran'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pelanggaran'));
        }
    }

    public function _rules() 
    {
        $this->form_validation->set_rules('id_pelanggaran', 'id pelanggaran', 'trim|required');
        $this->form_validation->set_rules('jenis_pelanggaran', 'jenis pelanggaran', 'trim|required');
        $this->form_validation->set_rules('bobot_nilai', 'bobot nilai', 'trim|required');

        $this->form_validation->set_rules('id_pelanggaran', 'id_pelanggaran', 'trim');
        $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "bkn_pelanggaran.xls";
        $judul = "bkn_pelanggaran";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
        xlsWriteLabel($tablehead, $kolomhead++, "Jenis Pelanggaran");
        xlsWriteLabel($tablehead, $kolomhead++, "Bobot Nilai");

        foreach ($this->Bkn_pelanggaran_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
            xlsWriteLabel($tablebody, $kolombody++, $data->jenis_pelanggaran);
            xlsWriteNumber($tablebody, $kolombody++, $data->bobot_nilai);

            $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=bkn_pelanggaran.doc");

        $data = array(
            'bkn_pelanggaran_data' => $this->Bkn_pelanggaran_model->get_all(),
            'start' => 0
            );
        
        $this->load->view('bkn_pelanggaran_doc',$data);
    }

}

/* End of file Bkn_pelanggaran.php */
/* Location: ./application/controllers/Bkn_pelanggaran.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-15 03:42:05 */
/* http://harviacode.com */