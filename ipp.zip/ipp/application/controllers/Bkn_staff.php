<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_staff extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_staff_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bkn_staff = $this->Bkn_staff_model->get_all_query();
        $jumlah_staff= $this->Bkn_staff_model->hitung_karyawan();
        $tot_gaji_karyawan = $this->Bkn_staff_model->hitung_gaji();
        $max_gaji = $this->Bkn_staff_model->max_gaji();
        $min_gaji = $this->Bkn_staff_model->min_gaji();
        $rata_rata_gaji = $this->Bkn_staff_model->rataan_gaji();
        $selisih = $this->Bkn_staff_model->selisih();
        $selisih_terendah = $this->Bkn_staff_model->selisih_pada_terendah();
        

        $data = array(
            'bkn_staff_data' => $bkn_staff,
            'total_karyawan' => $jumlah_staff,
            'total_gaji' => $tot_gaji_karyawan,
            'maximal_gaji' => $max_gaji,
            'minimal_gaji' => $min_gaji,
            'rata2_gaji' => $rata_rata_gaji,
            'selisih' => $selisih,
            'selisih_terhadap_terendah' => $selisih_terendah
            );

        //print_r($data);
        $this->template->load('template', 'bkn_staff/bkn_staff_list', $data);
    }


    /*public function selisih(){

        //$data['maximal'] = $this->Bkn_staff_model->max_gaji();
        //$data['minimal'] = $this->Bkn_staff_model->min_gaji();
        $data['hasil'] = $data['maximal'] - $data['minimal'];

        print_r($data);

        $this->template->load('template', 'bkn_staff_list', $data);
    }*/

    public function read($id) 
    {
        $row = $this->Bkn_staff_model->get_by_id($id);
        if ($row) {
            $data = array(
                'nip' => $row->nip,
                'nama_pejabat' => $row->nama_pejabat,
                'biro' => $row->biro,
                'jabatan' => $row->jabatan,
                'fungsi' => $row->fungsi,
                'gaji' => $row->gaji,
                );
            $this->template->load('template', 'bkn_staff/bkn_staff_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_staff'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_staff/create_action'),
            'nip' => set_value('nip'),
            'nama_pejabat' => set_value('nama_pejabat'),
            'biro' => set_value('biro'),
            'jabatan' => set_value('jabatan'),
            'fungsi' => set_value('fungsi'),
            'gaji' => set_value('gaji'),
            );
        $this->template->load('template', 'bkn_staff/bkn_staff_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
                'nip' => $this->input->post('nip', TRUE),
                'nama_pejabat' => $this->input->post('nama_pejabat',TRUE),
                'biro' => $this->input->post('biro',TRUE),
                'jabatan' => $this->input->post('jabatan',TRUE),
                'fungsi' => $this->input->post('fungsi',TRUE),
                'gaji' => $this->input->post('gaji',TRUE),
                );

            $this->Bkn_staff_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bkn_staff'));
        }
    }
    

    public function update($id) 
    {
        $row = $this->Bkn_staff_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bkn_staff/update_action'),
                'nip' => set_value('nip', $row->nip),
                'nama_pejabat' => set_value('nama_pejabat', $row->nama_pejabat),
                'biro' => set_value('biro', $row->biro),
                'jabatan' => set_value('jabatan', $row->jabatan),
                'fungsi' => set_value('fungsi', $row->fungsi),
                'gaji' => set_value('gaji', $row->gaji),
                );
            $this->template->load('template', 'bkn_staff/bkn_staff_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_staff'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('nip', TRUE));
        } else {
            $data = array(
                'nip' => $this->input->post('nip',TRUE),        
                'nama_pejabat' => $this->input->post('nama_pejabat',TRUE),
                'biro' => $this->input->post('biro',TRUE),
                'jabatan' => $this->input->post('jabatan',TRUE),
                'fungsi' => $this->input->post('fungsi',TRUE),
                'gaji' => $this->input->post('gaji',TRUE),
                );

            $this->Bkn_staff_model->update($this->input->post('nip', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_staff'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bkn_staff_model->get_by_id($id);

        if ($row) {
            $this->Bkn_staff_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_staff'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_staff'));
        }
    }

    public function _rules() 
    {
        $this->form_validation->set_rules('nip', 'nip', 'trim|required');
        $this->form_validation->set_rules('nama_pejabat', 'nama pejabat', 'trim|required');
        $this->form_validation->set_rules('biro', 'biro', 'trim|required');
        $this->form_validation->set_rules('jabatan', 'jabatan', 'trim|required');
        $this->form_validation->set_rules('fungsi', 'fungsi', 'trim|required');
        $this->form_validation->set_rules('gaji', 'gaji', 'trim|required');

        $this->form_validation->set_rules('nip', 'nip', 'trim');
        $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "bkn_staff.xls";
        $judul = "bkn_staff";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
        xlsWriteLabel($tablehead, $kolomhead++, "Nomor Induk Pegawai");    
        xlsWriteLabel($tablehead, $kolomhead++, "Nama Pejabat");
        xlsWriteLabel($tablehead, $kolomhead++, "Biro");
        xlsWriteLabel($tablehead, $kolomhead++, "Jabatan");
        xlsWriteLabel($tablehead, $kolomhead++, "Fungsi");
        xlsWriteLabel($tablehead, $kolomhead++, "Gaji");

        foreach ($this->Bkn_staff_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
            xlsWriteLabel($tablebody, $kolombody++, $data->nip);    
            xlsWriteLabel($tablebody, $kolombody++, $data->nama_pejabat);
            xlsWriteLabel($tablebody, $kolombody++, $data->biro);
            xlsWriteLabel($tablebody, $kolombody++, $data->jabatan);
            xlsWriteLabel($tablebody, $kolombody++, $data->fungsi);
            xlsWriteLabel($tablebody, $kolombody++, $data->gaji);

            $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=bkn_staff.doc");

        $data = array(
            'bkn_staff_data' => $this->Bkn_staff_model->get_all(),
            'start' => 0
            );
        
        $this->load('template', 'bkn_staff_doc',$data);
    }

}
