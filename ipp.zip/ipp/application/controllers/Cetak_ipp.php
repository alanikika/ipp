<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cetak_ipp extends CI_Controller
{


    function __construct()
    {
        parent::__construct();
        $this->load->model('Cetak_ipp_model');
        $this->load->model('Bkn_staff_biro_model');
        $this->load->model('Bkn_pendidikan_staff_model');
        $this->load->model('Bkn_pelatihan_staff_model');
        $this->load->model('Bkn_pengalaman_staff_model');
        $this->load->model('Bkn_diklat_staff_model');
        $this->load->model('Bkn_pelanggaran_staff_model');
        $this->load->model('Bkn_kinerja_biro_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if(!isset($_GET['biro_nama']) || $_GET['biro_nama'] == '')
        {
            $bkn_staff_biro = $this->Bkn_staff_biro_model->get_all_query();
            $bkn_hitung_karyawan = $this->Cetak_ipp_model->hitung_karyawan_semua();
            $bkn_gaps_pend = $this->Bkn_pendidikan_staff_model->total_gaps_semua();
            $bkn_gaps_pela = $this->Bkn_pelatihan_staff_model->total_gaps_semua();
            $bkn_gaps_penga = $this->Bkn_pengalaman_staff_model->total_gaps_semua();
            $bkn_gaps_diklat = $this->Bkn_diklat_staff_model->total_gaps_semua();
            $bkn_avg_kinerja_biro = $this->Bkn_kinerja_biro_model->avg_kinerja_biro_semua();
            
            $gaps_disiplin = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran_semua();

            $gaps_kompensasi = $this->Cetak_ipp_model->kompensasi_semua();


        }
        else 
        {
            $biron = $_GET['biro_nama'];            
            
            $bkn_staff_biro = $this->Bkn_staff_biro_model->cari_by_biro($biron);
            $bkn_hitung_karyawan = $this->Cetak_ipp_model->hitung_karyawan_biro($biron);
            $bkn_gaps_pend = $this->Bkn_pendidikan_staff_model->total_gaps_by_biro($biron);
            $bkn_gaps_pela = $this->Bkn_pelatihan_staff_model->total_gaps_by_biro($biron);
            $bkn_gaps_penga = $this->Bkn_pengalaman_staff_model->total_gaps_by_biro($biron);
            $bkn_gaps_diklat = $this->Bkn_diklat_staff_model->total_gaps_by_biro($biron);
            $bkn_avg_kinerja_biro = $this->Bkn_kinerja_biro_model->avg_kinerja_biro($biron);
            
            $gaps_disiplin = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran_biro($biron);

            $gaps_kompensasi = $this->Cetak_ipp_model->kompensasi_biro($biron);
        }

        $total_gaps_kompensasi=0;
        foreach ($gaps_kompensasi as $gaps_kompensasi) {
            $total_gaps_kompensasi += $gaps_kompensasi->spt;
        }

        $cetak_ipp = $this->Cetak_ipp_model->get_all();
        $staff_by_biro = $this->Bkn_staff_biro_model->get_biro();
        $total_gaps = (float)($bkn_gaps_pend + $bkn_gaps_pela + $bkn_gaps_penga + $bkn_gaps_diklat)/4;
        $rata_gaps = number_format($total_gaps/$bkn_hitung_karyawan, 2);
        //$bkn_rata_pelanggaran = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran_semua();

        $data = array(
            'cetak_ipp_data' => $cetak_ipp,
            'jmlh_karyawan' => $bkn_hitung_karyawan,
            'bkn_staff_biro_data' => $bkn_staff_biro,
            'biro' => $staff_by_biro,
            //'jabatan' => $staff_by_jabatan,
            'bkn_gaps_pend' => $bkn_gaps_pend,
            'bkn_gaps_pela' => $bkn_gaps_pela,
            'bkn_gaps_penga' => $bkn_gaps_penga,
            'bkn_gaps_diklat' => $bkn_gaps_diklat,
            'rata_gaps' => $rata_gaps,
            'rata_kinerja_biro' => $bkn_avg_kinerja_biro,
            'rata_pelanggaran' => $gaps_disiplin,
            'gaps_kompensasi' => $total_gaps_kompensasi
            );

        //print_r($gaps_kompensasi);
        $this->template->load('template','cetak_ipp_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Cetak_ipp_model->get_by_id($id);
        if ($row) {
            $data = array(
              'id' => $row->id,
              'nama' => $row->nama,
              );
            $this->template->load('template','cetak_ipp_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cetak_ipp'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('cetak_ipp/create_action'),
            'id' => set_value('id'),
            'nama' => set_value('nama'),
            );
        $this->template->load('template','cetak_ipp_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
              'id' => $this->input->post('id',TRUE),
              'nama' => $this->input->post('nama',TRUE),
              );

            $this->Cetak_ipp_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('cetak_ipp'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Cetak_ipp_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('cetak_ipp/update_action'),
                'id' => set_value('id', $row->id),
                'nama' => set_value('nama', $row->nama),
                );
            $this->template->load('template','cetak_ipp_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cetak_ipp'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('', TRUE));
        } else {
            $data = array(
              'id' => $this->input->post('id',TRUE),
              'nama' => $this->input->post('nama',TRUE),
              );

            $this->Cetak_ipp_model->update($this->input->post('', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('cetak_ipp'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Cetak_ipp_model->get_by_id($id);

        if ($row) {
            $this->Cetak_ipp_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('cetak_ipp'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cetak_ipp'));
        }
    }

    public function _rules() 
    {
       $this->form_validation->set_rules('id', 'id', 'trim|required');
       $this->form_validation->set_rules('nama', 'nama', 'trim|required');

       $this->form_validation->set_rules('', '', 'trim');
       $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
   }

   public function excel()
   {
    $this->load->helper('exportexcel');
    $namaFile = "cetak_ipp.xls";
    $judul = "cetak_ipp";
    $tablehead = 0;
    $tablebody = 1;
    $nourut = 1;
        //penulisan header
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment;filename=" . $namaFile . "");
    header("Content-Transfer-Encoding: binary ");

    xlsBOF();

    $kolomhead = 0;
    xlsWriteLabel($tablehead, $kolomhead++, "No");
    xlsWriteLabel($tablehead, $kolomhead++, "Id");
    xlsWriteLabel($tablehead, $kolomhead++, "Nama");

    foreach ($this->Cetak_ipp_model->get_all() as $data) {
        $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
        xlsWriteNumber($tablebody, $kolombody++, $nourut);
        xlsWriteNumber($tablebody, $kolombody++, $data->id);
        xlsWriteNumber($tablebody, $kolombody++, $data->nama);

        $tablebody++;
        $nourut++;
    }

    xlsEOF();
    exit();
}

public function word()
{
    header("Content-type: application/vnd.ms-word");
    header("Content-Disposition: attachment;Filename=cetak_ipp.doc");

    $data = array(
        'cetak_ipp_data' => $this->Cetak_ipp_model->get_all(),
        'start' => 0
        );

    $this->load->view('cetak_ipp_doc',$data);
}

}

/* End of file Cetak_ipp.php */
/* Location: ./application/controllers/Cetak_ipp.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-23 02:57:27 */
/* http://harviacode.com */