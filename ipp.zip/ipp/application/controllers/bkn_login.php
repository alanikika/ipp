 <?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class bkn_login extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_login_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
    	$cek = $this->session->userdata('logged_in');
		if(empty($cek))
		{
			$this->load->view('bkn_login');	
		}
		else
		{
			$st = $this->session->userdata('role');
			if($st=='1')
			{
				header('location:'.base_url().'index.php');	
			}
			
		}
    }

    public function login()
	{
		$u = $this->input->post('nip');
		$p = $this->input->post('password');
		$this->web_app_model->getLoginData($u,$p);
	}
}