<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_kinerja_biro extends CI_Controller
{


    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_kinerja_biro_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if(!isset($_GET['biro_nama']) || $_GET['biro_nama'] == '')
        {
            $bkn_kinerja_biro = $this->Bkn_kinerja_biro_model->get_all_query();
            $bkn_avg_kinerja_biro = $this->Bkn_kinerja_biro_model->avg_kinerja_biro_semua();    
        }
        else
        {
            $biron = $_GET['biro_nama'];

            $bkn_kinerja_biro = $this->Bkn_kinerja_biro_model->cari_biro($biron);
            $bkn_avg_kinerja_biro = $this->Bkn_kinerja_biro_model->avg_kinerja_biro($biron);    
        }
        
        $kinerja_by_biro = $this->Bkn_kinerja_biro_model->get_biro();

        $data = array(
            'bkn_kinerja_biro_data' => $bkn_kinerja_biro,
            'biro' => $kinerja_by_biro,
            'avg_kinerja_biro' => $bkn_avg_kinerja_biro
            );

        $this->template->load('template','bkn_kinerja_biro/bkn_kinerja_biro_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Bkn_kinerja_biro_model->get_by_id($id);
        if ($row) {
            $data = array(
              'id' => $row->id,
              'biro' => $row->biro,
              'jabatan' => $row->jabatan,
              'nilai_skp' => $row->nilai_skp,
              );
            $this->template->load('template','bkn_kinerja_biro/bkn_kinerja_biro_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_kinerja_biro'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_kinerja_biro/create_action'),
            'id' => set_value('id'),
            'biro' => set_value('biro'),
            'jabatan' => set_value('jabatan'),
            'nilai_skp' => set_value('nilai_skp'),
            );
        $this->template->load('template','bkn_kinerja_biro/bkn_kinerja_biro_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
              'biro' => $this->input->post('biro',TRUE),
              'jabatan' => $this->input->post('jabatan',TRUE),
              'nilai_skp' => $this->input->post('nilai_skp',TRUE),
              );

            $this->Bkn_kinerja_biro_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bkn_kinerja_biro'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Bkn_kinerja_biro_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bkn_kinerja_biro/update_action'),
                'id' => set_value('id', $row->id),
                'biro' => set_value('biro', $row->biro),
                'jabatan' => set_value('jabatan', $row->jabatan),
                'nilai_skp' => set_value('nilai_skp', $row->nilai_skp),
                );
            $this->template->load('template','bkn_kinerja_biro/bkn_kinerja_biro_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_kinerja_biro'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
              'biro' => $this->input->post('biro',TRUE),
              'jabatan' => $this->input->post('jabatan',TRUE),
              'nilai_skp' => $this->input->post('nilai_skp',TRUE),
              );

            $this->Bkn_kinerja_biro_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_kinerja_biro'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bkn_kinerja_biro_model->get_by_id($id);

        if ($row) {
            $this->Bkn_kinerja_biro_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_kinerja_biro'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_kinerja_biro'));
        }
    }

    public function _rules() 
    {
       $this->form_validation->set_rules('biro', 'biro', 'trim|required');
       $this->form_validation->set_rules('jabatan', 'jabatan', 'trim|required');
       $this->form_validation->set_rules('nilai_skp', 'nilai skp', 'trim|required');

       $this->form_validation->set_rules('id', 'id', 'trim');
       $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
   }

   public function excel()
   {
    $this->load->helper('exportexcel');
    $namaFile = "bkn_kinerja_biro.xls";
    $judul = "bkn_kinerja_biro";
    $tablehead = 0;
    $tablebody = 1;
    $nourut = 1;
        //penulisan header
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment;filename=" . $namaFile . "");
    header("Content-Transfer-Encoding: binary ");

    xlsBOF();

    $kolomhead = 0;
    xlsWriteLabel($tablehead, $kolomhead++, "No");
    xlsWriteLabel($tablehead, $kolomhead++, "Biro");
    xlsWriteLabel($tablehead, $kolomhead++, "Jabatan");
    xlsWriteLabel($tablehead, $kolomhead++, "Nilai SKP");

    foreach ($this->Bkn_kinerja_biro_model->get_all_query() as $data) {
        $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
        xlsWriteNumber($tablebody, $kolombody++, $nourut);
        xlsWriteNumber($tablebody, $kolombody++, $data->nama_biro);
        xlsWriteNumber($tablebody, $kolombody++, $data->nama_jabatan);
        xlsWriteLabel($tablebody, $kolombody++, $data->nilai_skp);

        $tablebody++;
        $nourut++;
    }

    xlsEOF();
    exit();
}

public function word()
{
    header("Content-type: application/vnd.ms-word");
    header("Content-Disposition: attachment;Filename=bkn_kinerja_biro.doc");

    $data = array(
        'bkn_kinerja_biro_data' => $this->Bkn_kinerja_biro_model->get_all_query(),
        'start' => 0
        );

    $this->load->view('bkn_kinerja_biro_doc',$data);
}

}

/* End of file Bkn_kinerja_biro.php */
/* Location: ./application/controllers/Bkn_kinerja_biro.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-20 07:10:47 */
/* http://harviacode.com */