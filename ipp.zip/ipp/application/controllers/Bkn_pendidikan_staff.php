<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_pendidikan_staff extends CI_Controller
{


    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_pendidikan_staff_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bkn_pendidikan_staff = $this->Bkn_pendidikan_staff_model->get_bobot();
    
        $data = array(
            'bkn_pendidikan_staff_data' => $bkn_pendidikan_staff,
            );
        $this->template->load('template','bkn_pendidikan_staff_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Bkn_pendidikan_staff_model->get_by_id($id);
        if ($row) {
            // $data = array(
            //   'id' => $row->id,
            //   'nip' => $row->nip,
            //   'pendidikan' => $row->pendidikan,
            //   );
            $data = array(
                'row' => $row,
                'nip' => $id,
                'pendidikan' => $row
                );
            $this->template->load('template','bkn_pendidikan_staff_read', $data);
        } else {
            echo 'gagal';
//            $this->session->set_flashdata('message', 'Record Not Found');
//            redirect(site_url('bkn_pendidikan_staff'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_pendidikan_staff/create_action'),
            'id' => set_value('id'),
            'nip' => set_value('nip'),
            'pendidikan' => set_value('pendidikan'),
            );
        $this->template->load('template','bkn_pendidikan_staff_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();
        
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
              'nip' => $this->input->post('nip',TRUE),
              'pendidikan' => $this->input->post('pendidikan',TRUE),
              );

            $test = $this->Bkn_pendidikan_staff_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            
            redirect(site_url('bkn_pendidikan_staff'));
        }
    }
    
    public function update($nip) 
    {
        $this->Bkn_pendidikan_staff_model->set_bobot($nip);

        // if ($row) {
        //     $data = array(
        //         'button' => 'Update',
        //         'action' => site_url('bkn_pendidikan_staff/update_action'),
        //         'id' => set_value('id', $row->id),
        //         'nip' => set_value('nip', $row->nip),
        //         'bobot' => set_value('bobot', $row->bobot),
        //         );
        //     $this->template->load('template','bkn_pendidikan_staff_form', $data);
        // } else {
        //     $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pendidikan_staff'));
        //}
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
              'nip' => $this->input->post('nip',TRUE),
              'bobot' => $this->input->post('bobot',TRUE),
              );

            $this->Bkn_pendidikan_staff_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_pendidikan_staff'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bkn_pendidikan_staff_model->get_by_id($id);

        if ($row) {
            $this->Bkn_pendidikan_staff_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_pendidikan_staff'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pendidikan_staff'));
        }
    }

    public function _rules() 
    {
       $this->form_validation->set_rules('nip', 'nip', 'trim|required');
       $this->form_validation->set_rules('pendidikan', 'pendidikan', 'trim|required');

       $this->form_validation->set_rules('id', 'id', 'trim');
       $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
   }

   public function excel()
   {
    $this->load->helper('exportexcel');
    $namaFile = "bkn_pendidikan_staff.xls";
    $judul = "bkn_pendidikan_staff";
    $tablehead = 0;
    $tablebody = 1;
    $nourut = 1;
        //penulisan header
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment;filename=" . $namaFile . "");
    header("Content-Transfer-Encoding: binary ");

    xlsBOF();

    $kolomhead = 0;
    xlsWriteLabel($tablehead, $kolomhead++, "No");
    xlsWriteLabel($tablehead, $kolomhead++, "Nip");
    xlsWriteLabel($tablehead, $kolomhead++, "Pendidikan");

    foreach ($this->Bkn_pendidikan_staff_model->get_all() as $data) {
        $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
        xlsWriteNumber($tablebody, $kolombody++, $nourut);
        xlsWriteLabel($tablebody, $kolombody++, $data->nip);
        xlsWriteLabel($tablebody, $kolombody++, $data->pendidikan);

        $tablebody++;
        $nourut++;
    }

    xlsEOF();
    exit();
}

public function word()
{
    header("Content-type: application/vnd.ms-word");
    header("Content-Disposition: attachment;Filename=bkn_pendidikan_staff.doc");

    $data = array(
        'bkn_pendidikan_staff_data' => $this->Bkn_pendidikan_staff_model->get_all(),
        'start' => 0
        );

    $this->load->view('bkn_pendidikan_staff_doc',$data);
}

}

/* End of file Bkn_pendidikan_staff.php */
/* Location: ./application/controllers/Bkn_pendidikan_staff.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-21 15:18:14 */
/* http://harviacode.com */