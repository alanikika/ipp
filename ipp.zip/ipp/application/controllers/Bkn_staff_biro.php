<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_staff_biro extends CI_Controller
{


    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_staff_biro_model');
        $this->load->model('Bkn_pendidikan_staff_model');
        $this->load->model('Bkn_pelatihan_staff_model');
        $this->load->model('Bkn_pengalaman_staff_model');
        $this->load->model('Bkn_diklat_staff_model');
        $this->load->model('Bkn_pelanggaran_staff_model');
        $this->load->model('Bkn_kinerja_biro_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if(!isset($_GET['jabatan_nama']) || $_GET['jabatan_nama'] == '')
        {
                $bkn_staff_biro = $this->Bkn_staff_biro_model->get_all_query();
                $bkn_hitung_karyawan = $this->Bkn_staff_biro_model->hitung_karyawan_semua();
                $bkn_hitung_gaji_biro = $this->Bkn_staff_biro_model->hitung_gaji_biro_semua();
                $bkn_max_gaji_biro = $this->Bkn_staff_biro_model->max_gaji_semua();
                $bkn_min_gaji_biro = $this->Bkn_staff_biro_model->min_gaji_semua();
                $bkn_avg_gaji_biro = $this->Bkn_staff_biro_model->avg_gaji_semua();
                $bkn_selisih_gaji_biro = $this->Bkn_staff_biro_model->selisih_gaji_semua();
                $bkn_sel_gaji_pd_terendah_biro = $this->Bkn_staff_biro_model->selisih_gaji_pada_terendah_semua();
                $bkn_gaps_pend = $this->Bkn_pendidikan_staff_model->total_gaps_semua();
                $bkn_gaps_pela = $this->Bkn_pelatihan_staff_model->total_gaps_semua();
                $bkn_gaps_penga = $this->Bkn_pengalaman_staff_model->total_gaps_semua();
                $bkn_gaps_diklat = $this->Bkn_diklat_staff_model->total_gaps_semua();
                $bkn_avg_kinerja_biro = $this->Bkn_kinerja_biro_model->avg_kinerja_biro_semua();

        }
        else 
        {
            $jabatann = $_GET['jabatan_nama'];            
            
            $bkn_staff_biro = $this->Bkn_staff_biro_model->cari_biro($jabatann);
            $bkn_hitung_karyawan = $this->Bkn_staff_biro_model->hitung_karyawan_biro($jabatann);
            $bkn_hitung_gaji_biro = $this->Bkn_staff_biro_model->hitung_gaji_biro($jabatann);
            $bkn_max_gaji_biro = $this->Bkn_staff_biro_model->max_gaji_biro($jabatann);
            $bkn_min_gaji_biro = $this->Bkn_staff_biro_model->min_gaji_biro($jabatann);
            $bkn_avg_gaji_biro = $this->Bkn_staff_biro_model->avg_gaji_biro($jabatann);
            $bkn_selisih_gaji_biro = $this->Bkn_staff_biro_model->selisih_gaji_biro($jabatann);
            $bkn_sel_gaji_pd_terendah_biro = $this->Bkn_staff_biro_model->selisih_gaji_pada_terendah_biro($jabatann);
            $bkn_gaps_pend = $this->Bkn_pendidikan_staff_model->total_gaps_by_biro($jabatann);
            $bkn_gaps_pela = $this->Bkn_pelatihan_staff_model->total_gaps_by_biro($jabatann);
            $bkn_gaps_penga = $this->Bkn_pengalaman_staff_model->total_gaps_by_biro($jabatann);
            $bkn_gaps_diklat = $this->Bkn_diklat_staff_model->total_gaps_by_biro($jabatann);
            $bkn_avg_kinerja_biro = $this->Bkn_kinerja_biro_model->avg_kinerja_biro($jabatann);


        }
        
            //$staff_by_biro = $this->Bkn_staff_biro_model->get_biro();
            $staff_by_jabatan = $this->Bkn_staff_biro_model->get_jabatan();
            $total_gaps = (float)($bkn_gaps_pend + $bkn_gaps_pela + $bkn_gaps_penga + $bkn_gaps_diklat)/4;
            $rata_gaps = number_format($total_gaps/$bkn_hitung_karyawan, 2);

             //$bkn_rata_pelanggaran = $this->Bkn_pelanggaran_staff_model->get_rata_pelanggaran();

        $data = array(
            'bkn_staff_biro_data' => $bkn_staff_biro,
            //'biro' => $staff_by_biro,
            'jabatan' => $staff_by_jabatan,
            'jmlh_karyawan' => $bkn_hitung_karyawan,
            'gaji_biro' => $bkn_hitung_gaji_biro,
            'max_gaji_biro' => $bkn_max_gaji_biro,
            'min_gaji_biro' => $bkn_min_gaji_biro,
            'avg_gaji_biro' => $bkn_avg_gaji_biro,
            'selisih_gaji_biro' => $bkn_selisih_gaji_biro,
            'sel_gaji_pd_terendah_biro' => $bkn_sel_gaji_pd_terendah_biro,
            'bkn_gaps_pend' => $bkn_gaps_pend,
            'bkn_gaps_pela' => $bkn_gaps_pela,
            'bkn_gaps_penga' => $bkn_gaps_penga,
            'bkn_gaps_diklat' => $bkn_gaps_diklat,
            'total_gaps'=> $total_gaps,
            'rata_gaps' => $rata_gaps,
            //'rata_pelanggaran' => $bkn_rata_pelanggaran,
            'rata_kinerja_biro' => $bkn_avg_kinerja_biro
            //'rata_gaps' => $rata_gaps
        );

        //print_r($rata_gaps);

        
       $this->template->load('template','bkn_staff_biro/bkn_staff_biro_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Bkn_staff_biro_model->get_by_id($id);
        if ($row) {
            $bobot_pend = $this->Bkn_pendidikan_staff_model->get_bobot_by_id($id);
            $bobot_pela = $this->Bkn_pelatihan_staff_model->get_bobot_by_id($id);
            $bobot_pengal = $this->Bkn_pengalaman_staff_model->get_bobot_by_id($id);
            $bobot_diklat = $this->Bkn_diklat_staff_model->get_bobot_by_id($id);
            //$ambil_gaps = $this->Bkn_staff_biro_model->ambil_gaps($id);

            if(!$bobot_pend) $bobot_pen = 'no entry';
            else $bobot_pen = $bobot_pend->pendidikan;
            
            if(!$bobot_pela) $bobot_pel = 'no entry';
            else $bobot_pel = $bobot_pela->pelatihan;

            if(!$bobot_pengal) $bobot_peng = 'no entry';
            else $bobot_peng = $bobot_pengal->pengalaman;

            if(!$bobot_diklat) $bobot_dklt = 'no entry';
            else $bobot_dklt = $bobot_diklat->diklat;

            $data = array(
              'nip' => $row->nip,
              'nama_pejabat' => $row->nama_pejabat,
              'biro' => $row->biro,
              'jabatan' => $row->jabatan,
              'fungsi' => $row->fungsi,
              'gaji' => $row->gaji,
              'bobot_pend' => $bobot_pen,
              'bobot_pela' => $bobot_pel,
              'bobot_pengal' => $bobot_peng,
              'bobot_diklat' => $bobot_dklt,
              //'ambil_gaps' => $ambil_gaps

              );
            //print_r($data);
            $this->template->load('template','bkn_staff_biro/bkn_staff_biro_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_staff_biro'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_staff_biro/create_action'),
            'nip' => set_value('nip'),
            'nama_pejabat' => set_value('nama_pejabat'),
            'biro' => set_value('biro'),
            'jabatan' => set_value('jabatan'),
            'fungsi' => set_value('fungsi'),
            'gaji' => set_value('gaji'),
            );
        $this->template->load('template','bkn_staff_biro/bkn_staff_biro_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
              'nama_pejabat' => $this->input->post('nama_pejabat',TRUE),
              'biro' => $this->input->post('biro',TRUE),
              'jabatan' => $this->input->post('jabatan',TRUE),
              'fungsi' => $this->input->post('fungsi',TRUE),
              'gaji' => $this->input->post('gaji',TRUE),
              );

            $this->Bkn_staff_biro_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bkn_staff_biro'));
        }
    }

    public function filter($id_biro)
    {
        $row = $this->Bkn_staff_biro_model->get_by_id($id);
    }
    
    public function update($id) 
    {
        $row = $this->Bkn_staff_biro_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bkn_staff_biro/update_action'),
                'nip' => set_value('nip', $row->nip),
                'nama_pejabat' => set_value('nama_pejabat', $row->nama_pejabat),
                'biro' => set_value('biro', $row->biro),
                'jabatan' => set_value('jabatan', $row->jabatan),
                'fungsi' => set_value('fungsi', $row->fungsi),
                'gaji' => set_value('gaji', $row->gaji),
                );
            $this->template->load('template','bkn_staff_biro/bkn_staff_biro_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_staff_biro'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('nip', TRUE));
        } else {
            $data = array(
              'nama_pejabat' => $this->input->post('nama_pejabat',TRUE),
              'biro' => $this->input->post('biro',TRUE),
              'jabatan' => $this->input->post('jabatan',TRUE),
              'fungsi' => $this->input->post('fungsi',TRUE),
              'gaji' => $this->input->post('gaji',TRUE),
              );

            $this->Bkn_staff_biro_model->update($this->input->post('nip', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_staff_biro'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bkn_staff_biro_model->get_by_id($id);

        if ($row) {
            $this->Bkn_staff_biro_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_staff_biro'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_staff_biro'));
        }
    }

    public function _rules() 
    {
       $this->form_validation->set_rules('nama_pejabat', 'nama pejabat', 'trim|required');
       $this->form_validation->set_rules('biro', 'biro', 'trim|required');
       $this->form_validation->set_rules('jabatan', 'jabatan', 'trim|required');
       $this->form_validation->set_rules('fungsi', 'fungsi', 'trim|required');
       $this->form_validation->set_rules('gaji', 'gaji', 'trim|required|numeric');

       $this->form_validation->set_rules('nip', 'nip', 'trim');
       $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
   }

   public function excel()
   {
    $this->load->helper('exportexcel');
    $namaFile = "bkn_staff.xls";
    $judul = "bkn_staff";
    $tablehead = 0;
    $tablebody = 1;
    $nourut = 1;
        //penulisan header
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment;filename=" . $namaFile . "");
    header("Content-Transfer-Encoding: binary ");

    xlsBOF();

    $kolomhead = 0;
    xlsWriteLabel($tablehead, $kolomhead++, "No");
    xlsWriteLabel($tablehead, $kolomhead++, "Nama Pejabat");
    xlsWriteLabel($tablehead, $kolomhead++, "Biro");
    xlsWriteLabel($tablehead, $kolomhead++, "Jabatan");
    xlsWriteLabel($tablehead, $kolomhead++, "Fungsi");
    xlsWriteLabel($tablehead, $kolomhead++, "Gaji");

    foreach ($this->Bkn_staff_biro_model->get_all() as $data) {
        $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
        xlsWriteNumber($tablebody, $kolombody++, $nourut);
        xlsWriteLabel($tablebody, $kolombody++, $data->nama_pejabat);
        xlsWriteNumber($tablebody, $kolombody++, $data->biro);
        xlsWriteNumber($tablebody, $kolombody++, $data->jabatan);
        xlsWriteLabel($tablebody, $kolombody++, $data->fungsi);
        xlsWriteNumber($tablebody, $kolombody++, $data->gaji);

        $tablebody++;
        $nourut++;
    }

    xlsEOF();
    exit();
}

public function word()
{
    header("Content-type: application/vnd.ms-word");
    header("Content-Disposition: attachment;Filename=bkn_staff.doc");

    $data = array(
        'bkn_staff_data' => $this->Bkn_staff_biro_model->get_all(),
        'start' => 0
        );

    $this->load->view('bkn_staff_doc',$data);
}

}

/* End of file Bkn_staff_biro.php */
/* Location: ./application/controllers/Bkn_staff_biro.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-14 03:46:33 */
/* http://harviacode.com */