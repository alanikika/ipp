<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_pengalaman_staff extends CI_Controller
{
    
        
    function __construct()
    {
        parent::__construct();
        $this->load->model('Bkn_pengalaman_staff_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $bkn_pengalaman_staff = $this->Bkn_pengalaman_staff_model->get_bobot();

        $data = array(
            'bkn_pengalaman_staff_data' => $bkn_pengalaman_staff
        );

        $this->template->load('template','bkn_pengalaman_staff/bkn_pengalaman_staff_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Bkn_pengalaman_staff_model->get_by_id($id);
        if ($row) {
            // $data = array(
            //   'id' => $row->id,
            //   'nip' => $row->nip,
            //   'pendidikan' => $row->pendidikan,
            //   );
            $data = array(
                'row' => $row,
                'nip' => $id,
                'pengalaman' => $row
                );
            $this->template->load('template','bkn_pengalaman_staff/bkn_pengalaman_staff_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pengalaman_staff'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('bkn_pengalaman_staff/create_action'),
	    'id' => set_value('id'),
	    'nip' => set_value('nip'),
	    'pengalaman' => set_value('pengalaman'),
	);
        $this->template->load('template','bkn_pengalaman_staff/bkn_pengalaman_staff_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nip' => $this->input->post('nip',TRUE),
		'pengalaman' => $this->input->post('pengalaman',TRUE),
	    );

            $this->Bkn_pengalaman_staff_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('bkn_pengalaman_staff'));
        }
    }
    
    public function update($nip) 
    {
        $this->Bkn_pengalaman_staff_model->set_bobot($nip);

       /* if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('bkn_pengalaman_staff/update_action'),
		'id' => set_value('id', $row->id),
		'nip' => set_value('nip', $row->nip),
		'pengalaman' => set_value('pengalaman', $row->pengalaman),
	    );
            //$this->template->load('template','bkn_pengalaman_staff/bkn_pengalaman_staff_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');*/
            redirect(site_url('bkn_pengalaman_staff'));
        //}
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'nip' => $this->input->post('nip',TRUE),
		'pengalaman' => $this->input->post('pengalaman',TRUE),
	    );

            $this->Bkn_pengalaman_staff_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('bkn_pengalaman_staff'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Bkn_pengalaman_staff_model->get_by_id($id);

        if ($row) {
            $this->Bkn_pengalaman_staff_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('bkn_pengalaman_staff'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('bkn_pengalaman_staff'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nip', 'nip', 'trim|required');
	$this->form_validation->set_rules('pengalaman', 'pengalaman', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "bkn_pengalaman_staff.xls";
        $judul = "bkn_pengalaman_staff";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nip");
	xlsWriteLabel($tablehead, $kolomhead++, "Pengalaman");

	foreach ($this->Bkn_pengalaman_staff_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nip);
	    xlsWriteNumber($tablebody, $kolombody++, $data->pengalaman);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=bkn_pengalaman_staff.doc");

        $data = array(
            'bkn_pengalaman_staff_data' => $this->Bkn_pengalaman_staff_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('bkn_pengalaman_staff_doc',$data);
    }

}

/* End of file Bkn_pengalaman_staff.php */
/* Location: ./application/controllers/Bkn_pengalaman_staff.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-16 05:14:54 */
/* http://harviacode.com */