<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_staff_model extends CI_Model
{

    public $table = 'bkn_staff';
    public $id = 'nip';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    function get_all_query(){
        $sql = "SELECT s.nip, s.nama_pejabat, b.nama_biro, j.nama_jabatan, s.fungsi, s.gaji FROM bkn_staff as s, bkn_biro as b, bkn_kelas_jabatan as j WHERE s.biro=b.id_biro AND s.jabatan=j.id_jabatan";
        return $this->db->query($sql)->result();
    }

    //hitung karyawan
    function hitung_karyawan(){

        $sql = $this->db->query("SELECT * FROM bkn_staff");
        return $sql->num_rows();
    }

    public function hitung_gaji(){
        $sql = "SELECT SUM(gaji) as juji FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public  function max_gaji(){
        $sql = "SELECT MAX(gaji) as maxgaj FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function min_gaji()
    {
        $sql = "SELECT MIN(gaji) as mingaj FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function rataan_gaji(){
        $sql = "SELECT AVG(gaji) as avggaj FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function selisih(){
        $sql = "SELECT MAX(gaji) - MIN(gaji) as mm FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function selisih_pada_terendah(){
        $sql = "SELECT (MAX(gaji) - MIN(gaji)) / MIN(gaji) as spt FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function get_nilai_pelatihan($nip){
        $sql = "SELECT nip, count(pelatihan) as pelatihan from bkn_pelatihan_staff WHERE nip='$nip'";
        return $this->db->query($sql)->result();
    }
    
    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('nip', $q); 
        $this->db->or_like('nama_pejabat', $q);
        $this->db->or_like('biro', $q);
        $this->db->or_like('jabatan', $q);
        $this->db->or_like('fungsi', $q);
        $this->db->or_like('gaji', $q);
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('nip', $q);
        $this->db->or_like('nama_pejabat', $q);
        $this->db->or_like('biro', $q);
        $this->db->or_like('jabatan', $q);
        $this->db->or_like('fungsi', $q);
        $this->db->or_like('gaji', $q);
        $this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}
