<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class bkn_login_model extends CI_Model
{
    public function getLoginData($nip,$psw)
    {
        $u = mysql_real_escape_string($nip);
        $p = md5(mysql_real_escape_string($psw));
        
        $q_cek_login = $this->db->get_where('bkn_login', array('nip' => $u, 'password' => $p));
        if(count($q_cek_login->result())>0)
        {
            foreach ($q_cek_login->result() as $qck)
            {
                if($qck->role=='1')
                {
                    $q_ambil_data = $this->db->get_where('bkn_staff', array('nip' => $u));
                    foreach($q_ambil_data -> result() as $qad)
                    {
                        $sess_data['logged_in']     = 'yes';
                        $sess_data['nip']           = $qad->nim;
                        $sess_data['role']          = '1';
                        $this->session->set_userdata($sess_data);
                    }
                    header('location:'.base_url().'index.php/');
                }
        }

}
