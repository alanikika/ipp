<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_pelatihan_staff_model extends CI_Model
{

    public $table = 'bkn_pelatihan_staff';
    public $id = 'id';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    function set_bobot($nip)
    {
        //$this->db->where($this->nip, $nip);
        $sql = "select bobot from bkn_bobot_pelatihan where nip = '$nip'";
        
        $hasil = $this->db->query($sql)->result();
        foreach ($hasil as $row)
            $bobot = $row->bobot;
        
        if($bobot == 0)
            $sql = "update bkn_bobot_pelatihan set bobot = 1 where nip = '$nip'";
        else
            $sql = "update bkn_bobot_pelatihan set bobot = 0 where nip = '$nip'";
        
        $this->db->query($sql) ;
    }

    function get_bobot(){
        $sql = "SELECT nip, bobot from bkn_bobot_pelatihan";
        return $this->db->query($sql)->result();
    }

    function get_bobot_by_id($nip){
        $sql = "SELECT bobot as pelatihan from bkn_bobot_pelatihan WHERE nip='$nip'";
        return $this->db->query($sql)->row();
    }

    // get data by id
    function get_by_id($nip)
    {
        /*$sql = "SELECT a.bobot_nilai, a.jenis_pelanggaran, b.nip, b.id FROM bkn_pelanggaran as a, bkn_pelanggaran_staff as b WHERE a.id_pelanggaran=b.id_pelanggaran AND b.nip='$nip'";*/
         $sql = "SELECT nip, pelatihan FROM bkn_pelatihan_staff WHERE nip='$nip'";
        return $this->db->query($sql)->result();
    }

    public function total_gaps_Semua()
    {
        $sql = "SELECT SUM(bobot) as bobot FROM bkn_bobot_pelatihan";
        $hasil = $this->db->query($sql)->result();
        foreach ($hasil as $hasil) {
            $jumlah = $hasil->bobot;
        }

        return $jumlah;
    }

    public function total_gaps_by_jabatan($jabataan)
    {
        $sql = "SELECT SUM(bobot) as bobot FROM bkn_bobot_pelatihan as p, bkn_staff as s WHERE s.jabatan='$jabataan' AND s.nip = p.nip";
        $hasil = $this->db->query($sql)->result();
        foreach ($hasil as $hasil) {
            $jumlah = $hasil->bobot;
        }

        return $jumlah;
    }

    public function total_gaps_by_biro($biroo)
    {
        $sql = "SELECT SUM(bobot) as bobot FROM bkn_bobot_pelatihan as p, bkn_staff as s WHERE s.biro='$biroo' AND s.nip = p.nip";
        $hasil = $this->db->query($sql)->result();
        foreach ($hasil as $hasil) {
            $jumlah = $hasil->bobot;
        }

        return $jumlah;
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id', $q);
	$this->db->or_like('nip', $q);
	$this->db->or_like('pelatihan', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id', $q);
	$this->db->or_like('nip', $q);
	$this->db->or_like('pelatihan', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);

        $sql = "SELECT count(nip) as hitung FROM bkn_bobot_pelatihan WHERE nip='$data[nip]'";
        $hasil = $this->db->query($sql)->result();
        foreach ($hasil as $q) {
            $c = $q->hitung;

            if($c == 0){
                $sql = "INSERT INTO bkn_bobot_pelatihan (nip,bobot) VALUES ('$data[nip]',0)";
                $this->db->query($sql);
            }
        }
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
       $sql ="DELETE FROM bkn_pelatihan_staff WHERE id='$id'";
       $this->db->query($sql);
       return 0;
    }

}