<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Bkn_staff_biro_model extends CI_Model
{

    public $table = 'bkn_staff';
    public $id = 'nip';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    function get_all_query(){
        $sql = "SELECT s.nip, s.nama_pejabat, b.nama_biro, j.nama_jabatan, s.fungsi, s.gaji FROM bkn_staff as s, bkn_biro as b, bkn_kelas_jabatan as j WHERE s.biro=b.id_biro AND s.jabatan=j.id_jabatan";
        return $this->db->query($sql)->result();
    }

    function cari_biro($jabataan){
        $sql = "SELECT s.nip, s.nama_pejabat, b.nama_biro, j.nama_jabatan, s.fungsi, s.gaji FROM bkn_staff as s, bkn_biro as b, bkn_kelas_jabatan as j WHERE s.biro=b.id_biro AND s.jabatan=j.id_jabatan AND s.jabatan = $jabataan";

        return $this->db->query($sql)->result();
    }

    function cari_by_biro($biroo){
        $sql = "SELECT s.nip, s.nama_pejabat, b.nama_biro, j.nama_jabatan, s.fungsi, s.gaji FROM bkn_staff as s, bkn_biro as b, bkn_kelas_jabatan as j WHERE s.biro=b.id_biro AND s.jabatan=j.id_jabatan AND s.nip = $biroo";

        return $this->db->query($sql)->result();
    }

    function hitung_karyawan_semua(){

        $sql = $this->db->query("SELECT * FROM bkn_staff");
        return $sql->num_rows();
    }

    public function hitung_gaji_biro_semua (){
        $sql = "SELECT SUM(gaji) as gajibiro FROM bkn_staff";
        return $this->db->query($sql)->result();
    }


    public function max_gaji_semua (){
        $sql = "SELECT max(gaji) as maxgajibiro FROM bkn_staff";
        return $this->db->query($sql)->result();
    } 

    public function min_gaji_semua (){
        $sql = "SELECT min(gaji) as mingajibiro FROM bkn_staff";
        return $this->db->query($sql)->result();
    } 

    public function avg_gaji_semua (){
        $sql = "SELECT avg(gaji) as avggajibiro FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function selisih_gaji_semua(){
        $sql = "SELECT MAX(gaji) - MIN(gaji) as selisihgaji FROM bkn_staff";
        return $this->db->query($sql)->result();
    }

    public function selisih_gaji_pada_terendah_semua(){
        $sql = "SELECT (MAX(gaji) - MIN(gaji)) / MIN(gaji) as spt FROM bkn_staff";
        return $this->db->query($sql)->result();
    } 

    public function hitung_karyawan_biro($jabataan){
        $sql = $this->db->query("SELECT * FROM bkn_staff WHERE jabatan=$jabataan");
        return $sql->num_rows();
    }  
    
    public function hitung_gaji_biro($jabataan){
        $sql = "SELECT SUM(gaji) as gajibiro FROM bkn_staff WHERE jabatan=$jabataan";
        return $this->db->query($sql)->result();
    }

    public function max_gaji_biro($jabataan){
        $sql = "SELECT max(gaji) as maxgajibiro FROM bkn_staff WHERE jabatan=$jabataan";
        return $this->db->query($sql)->result();
    }

    public function min_gaji_biro($jabataan){
        $sql = "SELECT min(gaji) as mingajibiro FROM bkn_staff WHERE jabatan=$jabataan";
        return $this->db->query($sql)->result();
    }

    public function avg_gaji_biro($jabataan){
        $sql = "SELECT avg(gaji) as avggajibiro FROM bkn_staff WHERE jabatan=$jabataan";
        return $this->db->query($sql)->result();
    }

    public function selisih_gaji_biro($jabataan){
        $sql = "SELECT MAX(gaji) - MIN(gaji) as selisihgaji FROM bkn_staff WHERE jabatan=$jabataan";
        return $this->db->query($sql)->result();
    } 

    public function selisih_gaji_pada_terendah_biro($jabataan){
        $sql = "SELECT (MAX(gaji) - MIN(gaji)) / MIN(gaji) as spt FROM bkn_staff WHERE jabatan=$jabataan";
        return $this->db->query($sql)->result();
    }

    

    public function ambil_gaps($nip)
    {
        $sql = "SELECT bkn_bobot_pelatihan.bobot as pel, bkn_bobot_diklat.bobot as dik, bkn_bobot_pengalaman.bobot as peng, bkn_bobot_pendidikan.bobot as pen from bkn_bobot_pelatihan JOIN bkn_bobot_diklat on bkn_bobot_diklat.nip = bkn_bobot_pelatihan.nip JOIN bkn_bobot_pendidikan on bkn_bobot_pendidikan.nip = bkn_bobot_pelatihan.nip join bkn_bobot_pengalaman on bkn_bobot_pengalaman.nip = bkn_bobot_pelatihan.nip"  ; 
        return $this->db->query($sql)->result();  
    }


    // get data by id
    function get_by_id($id)
    {
        /*$sql = $this->db->query("SELECT s.nip, s.nama_pejabat, b.nama_biro, j.nama_jabatan, s.fungsi, s.gaji FROM bkn_staff as s, bkn_biro as b, bkn_kelas_jabatan as j WHERE s.biro=b.id_biro AND s.jabatan=j.id_jabatan");
        return $this->db->get($this->table)->row();*/

        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }

    public function get_jabatan(){
        $sql = "SELECT id_jabatan, nama_jabatan as j FROM bkn_kelas_jabatan";
        return $this->db->query($sql)->result();
    }

    public function get_biro(){
        $sql = "SELECT id_biro, nama_biro as b FROM bkn_biro";
        return $this->db->query($sql)->result();
    }

    /*function get_by_biro(){
        $sql = "SELECT SELECT nip, nama_pejabat, jabatan, fungsi, gaji FROM bkn_staff WHERE biro = '$biro' ";
        return $this->db->query($sql)->result();
    }*/
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('nip', $q);
        $this->db->or_like('nama_pejabat', $q);
        $this->db->or_like('biro', $q);
        $this->db->or_like('jabatan', $q);
        $this->db->or_like('fungsi', $q);
        $this->db->or_like('gaji', $q);
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('nip', $q);
        $this->db->or_like('nama_pejabat', $q);
        $this->db->or_like('biro', $q);
        $this->db->or_like('jabatan', $q);
        $this->db->or_like('fungsi', $q);
        $this->db->or_like('gaji', $q);
        $this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

/* End of file Bkn_staff_biro_model.php */
/* Location: ./application/models/Bkn_staff_biro_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2016-11-14 03:46:33 */
/* http://harviacode.com */