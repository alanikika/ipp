
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'>URAIAN PENILAIAN &nbsp <?php echo anchor('cetak_ipp/create/','Create',array('class'=>'btn btn-primary btn-sm'));?>
              <?php echo anchor(site_url('cetak_ipp/excel'), ' <i class="fa fa-file-excel-o"></i> Excel', 'class="btn btn-warning btn-sm"'); ?>
              <?php echo anchor(site_url('cetak_ipp/word'), '<i class="fa fa-file-word-o"></i> Word', 'class="btn btn-warning btn-sm"'); ?>
              <?php echo anchor(site_url('cetak_ipp/pdf'), '<i class="fa fa-file-pdf-o"></i> PDF', 'class="btn btn-warning btn-sm"'); ?></h3>

              <br><br>
              <body>
               <div>
                  <form action=<?php echo base_url().'index.php/cetak_ipp' ?>>
                  <select name="biro_nama">
                      <option value='' selected="selected">-----Tampilkan Biro----</option>
                      <?php foreach($biro as $biro):?>
                        <option value="<?php echo $biro->id_biro?>"><?php echo $biro->b?></option>
                    <?php endforeach;?>
                </select> &nbsp
                <button type="submit" class="btn btn-primary"><?php echo "Sort" ?></button> 
            </form>
        </div>
    </body>

</div><!-- /.box-header -->
<div class='box-body'>
    <table class="table table-bordered table-striped" id="mytable2">
        <thead>
          <tr>
            <th><center>Gaps Kompetensi</th>
            <th><center>Gaps Kompensasi</th>
            <th><center>Kinerja</th>
            <th><center>Indisipliner </th>
            <th><center>IPP </th>
            <tr>
            </thead>
            <tbody>
              <tr>
                    <td> <center>
                      <?php
                        echo number_format($rata_gaps, 2);
                      ?>
                      <td><center>
                        <?php
                        
                          echo (float) number_format($gaps_kompensasi,1);
                        
                        ?>
                      </td>
                      <td><center>
                        <?php
                        foreach ($rata_kinerja_biro as $rata_kinerja_biro) {
                          //$rata_kine = $rata_kinerja_biro->avgskp;
                          echo number_format($rata_kinerja_biro->avgskp, 2);
                        }
                        ?>
                      </td>
                      <td><center>
                        <?php
                        foreach ($rata_pelanggaran as $rata_pelanggaran) {
                          //$rata_pela = $rata_pelanggaran->rata;
                          echo number_format($rata_pelanggaran->rata, 2);
                        }
                        ?>
                      </td>
                      <td><center>
                        <?php
                          $ipp = ((25*(1-($rata_gaps))) + (25*(1-($gaps_kompensasi))) +((25*$rata_kinerja_biro->avgskp)/100) + (25*(1-($rata_pelanggaran->rata))));
                          /*$ipp = ((25*(1-$rata_pelanggaran->rata)) + (25*(1-$rata_kinerja_biro->avgskp)) + $rata_gaps);*/
                          echo number_format($ipp, 2);
                        ?>
                    </td>
                </tr>
            </tbody>

        </table>
        <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>
    </div><!-- /.box-body -->
</div><!-- /.box -->
</div><!-- /.col -->
</div><!-- /.row -->
        </section><!-- /.content -->