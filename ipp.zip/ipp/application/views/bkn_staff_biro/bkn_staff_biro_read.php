
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'>DETAIL STAFF</h3>
          <table class="table table-bordered">
           <tr><td>Nama Pejabat</td><td><?php echo $nama_pejabat; ?></td></tr>
           <tr><td>Biro</td><td><?php echo $biro; ?></td></tr>
           <tr><td>Jabatan</td><td><?php echo $jabatan; ?></td></tr>
           <tr><td>Fungsi</td><td><?php echo $fungsi; ?></td></tr>
           <tr><td>Gaji</td><td><?php echo "Rp " ?> <?php echo number_format($gaji,2); ?></td></tr>
           <tr><td>Bobot Pendidikan</td>
                <td><?php if($bobot_pend==0){ ?>
                      <?php echo "Y";
                      } else {?>
                      <?php echo "N"; ?>
                    <?php } ?>
                </td>
           <!-- <td><?php echo $bobot_pend; ?></td> -->
           </tr>
           <tr><td>Bobot Pelatihan</td>
                  <td><?php if($bobot_pela==0){ ?>
                      <?php echo "Y";
                      } else {?>
                      <?php echo "N"; ?>
                    <?php } ?>
                </td>
           </tr>
           <tr><td>Bobot Pengalaman</td>
                  <td><?php if($bobot_pengal==0){ ?>
                      <?php echo "Y";
                      } else {?>
                      <?php echo "N"; ?>
                    <?php } ?>
                </td>
           </tr>
           <tr><td>Bobot Diklat</td>
                  <td><?php if($bobot_diklat==0){ ?>
                    <?php echo "Y";
                    } else {?>
                    <?php echo "N"; ?>
                  <?php } ?>
              </td>
              <?php $gaps = (float)(0.25 * $bobot_pend) + (0.25 * $bobot_pela) + (0.25 * $bobot_pengal) + (0.25 * $bobot_diklat); ?>
           <tr><td><b>Penilaian Objektif</td><td><?php echo $gaps; ?></td></tr>
           <tr><td></td><td><a href="<?php echo site_url('bkn_staff_biro') ?>" class="btn btn-default">Cancel</a></td></tr>
         </table>
       </div><!-- /.box-body -->
     </div><!-- /.box -->
   </div><!-- /.col -->
 </div><!-- /.row -->
        </section><!-- /.content -->