
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'>LIST STAFF
            <?php echo anchor(site_url('bkn_staff_biro/excel'), ' <i class="fa fa-file-excel-o"></i> Excel', 'class="btn btn-warning btn-sm"'); ?>
            <?php echo anchor(site_url('bkn_staff_biro/word'), '<i class="fa fa-file-word-o"></i> Word', 'class="btn btn-warning btn-sm"'); ?>
            <?php echo anchor(site_url('bkn_staff_biro/pdf'), '<i class="fa fa-file-pdf-o"></i> PDF', 'class="btn btn-warning btn-sm"'); ?></h3>
            <br><br>
            <body>
             <div>
              <form action=<?php echo base_url().'index.php/bkn_staff_biro' ?>>
                <select name="jabatan_nama">
                  <option value='' selected="selected">-----Tampilkan Semua Pegawai----</option>
                  <?php foreach($jabatan as $jabatan):?>
                    <option value="<?php echo $jabatan->id_jabatan?>"><?php echo $jabatan->j?></option>
                  <?php endforeach;?>
                </select> &nbsp
                <button type="submit" class="btn btn-primary"><?php echo "Sort" ?></button> 
              </form>
            </div>
          </body>
        </div><!-- /.box-header -->


        <div class='box-body'>     
          <table class="table table-bordered table-striped" id="mytable">
            <thead>
              <tr>
                <th width="80px">No</th>
                <th>NIP</th>
                <th>Nama Pejabat</th>
                <th>Biro</th>
                <th>Jabatan</th>
                <th>Fungsi</th>
                <th>Gaji</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $start = 0;
              foreach ($bkn_staff_biro_data as $bkn_staff_biro)
              {
                ?>
                <tr>
                  <td><?php echo ++$start ?></td>
                  <td><?php echo $bkn_staff_biro->nip ?></td>
                  <td><?php echo $bkn_staff_biro->nama_pejabat ?></td>
                  <td><?php echo $bkn_staff_biro->nama_biro ?></td>
                  <td><?php echo $bkn_staff_biro->nama_jabatan ?></td>
                  <td><?php echo $bkn_staff_biro->fungsi ?></td>
                  <td><?php echo number_format($bkn_staff_biro->gaji, 2) ?></td>

                  <td style="text-align:center" width="140px">
                   <?php 
                   echo anchor(site_url('bkn_staff_biro/read/'.$bkn_staff_biro->nip),'<i class="fa fa-eye"></i>',array('title'=>'detail','class'=>'btn btn-sekundary btn-sm')); 
                   echo '  '; 
                   echo anchor(site_url('bkn_staff_biro/update/'.$bkn_staff_biro->nip),'<i class="fa fa-pencil-square-o"></i>',array('title'=>'edit','class'=>'btn btn-primary btn-sm')); 
                   echo '  '; 
                   echo anchor(site_url('bkn_staff_biro/delete/'.$bkn_staff_biro->nip),'<i class="fa fa-trash-o"></i>','title="delete" class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
                   ?>
                 </td>
               </tr>
               <?php
             }
             ?>
           </tbody>
         </table>
         <div class='box-body'>
          <table class="table table-bordered table-striped" id="mytable2">
            <thead>
              <tr>
                <th><center>Jumlah Pegawai</th>
                <th><center>Total Gaji</th>
                <th><center>Gaji Maksimum</th>
                <th><center>Gaji Minimum</th>
                <tr>
                </thead>
                <tbody>
                  <tr>
                    <td> <center>
                      <?php echo $jmlh_karyawan?>
                    </td>
                    <td><center>
                      <?php 
                      foreach ($gaji_biro as $gbiro) {
                        echo number_format($gbiro->gajibiro, 2);
                      }
                      ?>
                    </td>
                    <td><center>
                     <?php
                     foreach ($max_gaji_biro as $mgajibiro) {
                      echo number_format($mgajibiro->maxgajibiro, 2);
                    }
                    ?>
                  </td>
                  <td><center>
                   <?php
                   foreach ($min_gaji_biro as $mgajibiro) {
                    echo number_format($mgajibiro->mingajibiro, 2);
                  }
                  ?>
                </td>
              </tr>
            </tbody>
          </table>
          <br>
          <table class="table table-bordered table-striped" id="mytable2">
            <thead>
              <tr>
                <th><center>Gaji Rata-Rata</th>
                <th><center>Selisih Gaji Maks dan Min (S)</th>
                <th><center>Rasio</th>
                <th><center>Total Rasio </th>
                <tr>
                </thead>
                <tbody>
                  <tr>
                    <td> <center>
                      <?php
                      foreach ($avg_gaji_biro as $avggajibiro) {
                        echo number_format($avggajibiro->avggajibiro, 2);
                      }
                      ?>
                      <td><center>
                        <?php
                        foreach ($selisih_gaji_biro as $selgajibiro) {
                          echo number_format($selgajibiro->selisihgaji, 2);
                        }
                        ?>
                      </td>
                      <td><center>
                        <?php
                        foreach ($sel_gaji_pd_terendah_biro as $sgpthb) {
                          echo number_format($sgpthb->spt, 2);
                        }
                        ?>
                      </td>
                      <td><center>
                        <?php
                          echo $rata_gaps;
                        
                        ?>
                      </td>
                    </tr>
                  </tbody>

                </table>
                <br>
          <!-- <table class="table table-bordered table-striped" id="mytable2">
            <thead>
              <tr>
                <th><center>Gaps Kompetensi</th>
                <th><center>Gaps Kompensasi</th>
                <th><center>Kinerja</th>
                <th><center>Indisipliner </th>
                <th><center>IPP </th>
                <tr>
                </thead>
                <tbody>
                  <tr>
                    <td> <center>
                      <?php
                        echo number_format($rata_gaps,2);
                      ?>
                      <td><center>
                        <?php
                        echo '';
                        ?>
                      </td>
                      <td><center>
                        <?php
                        foreach ($rata_kinerja_biro as $rata_kinerja_biro) {
                          //$rata_kine = $rata_kinerja_biro->avgskp;
                          echo number_format($rata_kinerja_biro->avgskp, 2);
                        }
                        ?>
                      </td>
                      <td><center>
                        <?php
                        foreach ($rata_pelanggaran as $rata_pelanggaran) {
                          //$rata_pela = $rata_pelanggaran->rata;
                          echo number_format($rata_pelanggaran->rata, 2);
                        }
                        ?>
                      </td>
                      <td><center>
                        <?php
                          $ipp = $rata_pelanggaran->rata + $rata_kinerja_biro->avgskp + $rata_gaps;
                          echo number_format($ipp, 2);
                        ?>
                      </td>
                    </tr>
                  </tbody> -->

                </table>
              </div>
              <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
              <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
              <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
              <script type="text/javascript">
                $(document).ready(function () {
                  $("#mytable").dataTable();
                });
              </script>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div><!-- /.col -->
      </div><!-- /.row -->
        </section><!-- /.content -->