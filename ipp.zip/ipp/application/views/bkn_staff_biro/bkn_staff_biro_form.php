<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          
          <h3 class='box-title'>CREATE STAFF</h3>
          <div class='box box-primary'>
            <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
             <tr><td>Nama Pejabat <?php echo form_error('nama_pejabat') ?></td>
              <td><input type="text" class="form-control" name="nama_pejabat" id="nama_pejabat" placeholder="Nama Pejabat" value="<?php echo $nama_pejabat; ?>" />
              </td>
              <tr><td>Biro <?php echo form_error('biro') ?></td>
                <td><input type="text" class="form-control" name="biro" id="biro" placeholder="Biro" value="<?php echo $biro; ?>" />
                </td>
                <tr><td>Jabatan <?php echo form_error('jabatan') ?></td>
                  <td><input type="text" class="form-control" name="jabatan" id="jabatan" placeholder="Jabatan" value="<?php echo $jabatan; ?>" />
                  </td>
                  <tr><td>Fungsi <?php echo form_error('fungsi') ?></td>
                    <td><input type="text" class="form-control" name="fungsi" id="fungsi" placeholder="Fungsi" value="<?php echo $fungsi; ?>" />
                    </td>
                    <tr><td>Gaji <?php echo form_error('gaji') ?></td>
                      <td><input type="text" class="form-control" name="gaji" id="gaji" placeholder="Gaji" value="<?php echo $gaji; ?>" />
                      </td>
                      <input type="hidden" name="nip" value="<?php echo $nip; ?>" /> 
                      <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
                       <a href="<?php echo site_url('bkn_staff_biro') ?>" class="btn btn-default">Cancel</a></td></tr>
                       
                     </table></form>
                   </div><!-- /.box-body -->
                 </div><!-- /.box -->
               </div><!-- /.col -->
             </div><!-- /.row -->
        </section><!-- /.content -->