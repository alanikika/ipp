    <!-- Main content -->
    <section class='content'>
      <div class='row'>
        <div class='col-xs-12'>
          <div class='box'>
            <div class='box-header'>

            <h3 class='box-title'>FORM PENGISIAN PEGAWAI</h3>
              <div class='box box-primary'>
                <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
                  <tr><td>Nama Pejabat <?php echo form_error('nama_pejabat') ?></td>
                    <td><input type="text" class="form-control" name="nama_pejabat" id="nama_pejabat" placeholder="Nama Pejabat" value="<?php echo $nama_pejabat; ?>" />
                    </td>
                    <tr><td>NIP <?php echo form_error('nip') ?></td>
                    <td><input type="text" class="form-control" name="nip" id="nip" placeholder="Nomor Induk Pegawai" value="<?php echo $nip; ?>" />
                    </td>
                    <tr><td>Biro <?php echo form_error('biro') ?></td>
                      <td> <?php echo cmb_dinamis('biro', 'bkn_biro', 'nama_biro', 'id_biro', 'biro') ?>
                      </td>
                      <tr><td>Jabatan <?php echo form_error('jabatan') ?></td>
                        <td><?php echo cmb_dinamis('jabatan', 'bkn_kelas_jabatan', 'nama_jabatan', 'id_jabatan', 'jabatan') ?>
                        </td>
                        <tr><td>Fungsi <?php echo form_error('fungsi') ?></td>
                          <td><input type="text" class="form-control" name="fungsi" id="fungsi" placeholder="Fungsi" value="<?php echo $fungsi; ?>" />
                          </td>
                          <tr><td>Gaji <?php echo form_error('gaji') ?></td>
                            <td><input type="text" class="form-control" name="gaji" id="gaji" placeholder="Gaji" value="<?php echo $gaji; ?>" />
                            </td>
                            <!-- <input type="hidden" name="nip" value="<?php echo $nip; ?>" />  -->
                            <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
                              <a href="<?php echo site_url('bkn_staff') ?>" class="btn btn-default">Cancel</a></td></tr>

                            </table></form>
                          </div><!-- /.box-body -->
                        </div><!-- /.box -->
                      </div><!-- /.col -->
                    </div><!-- /.row -->
    </section><!-- /.content -->