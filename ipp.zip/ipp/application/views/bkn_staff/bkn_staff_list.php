
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'><b>DATA PEGAWAI </b> &nbsp &nbsp &nbsp <?php echo anchor('bkn_staff/create/','Create',array('class'=>'btn btn-primary btn-sm'));?>
              <?php echo anchor(site_url('bkn_staff/excel'), ' <i class="fa fa-file-excel-o"></i> Excel', 'class="btn btn-warning btn-sm"'); ?>
              <?php echo anchor(site_url('bkn_staff/word'), '<i class="fa fa-file-word-o"></i> Word', 'class="btn btn-warning btn-sm"'); ?>
              <?php echo anchor(site_url('bkn_staff/pdf'), '<i class="fa fa-file-pdf-o"></i> PDF', 'class="btn btn-warning btn-sm"'); ?></h3>
          </div><!-- /.box-header -->

        <div class='box-body'>
            <table class="table table-bordered table-striped" id="mytable">
                <thead>
                    <tr>
                        <th width="80px">No</th>
                        <th>NIP</th>
                        <th>Nama Pejabat</th>
                        <th>Biro</th>
                        <th>Jabatan</th>
                        <th>Fungsi</th>
                        <th>Gaji</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $start = 0;
                    foreach ($bkn_staff_data as $bkn_staff)
                    {
                        ?>
                        <tr>
                          <td><?php echo ++$start ?></td>
                          <td><?php echo $bkn_staff->nip ?></td>
                          <td><?php echo $bkn_staff->nama_pejabat ?></td>
                          <td><?php echo $bkn_staff->nama_biro ?></td>
                          <td><?php echo $bkn_staff->nama_jabatan ?></td>
                          <td><?php echo $bkn_staff->fungsi ?></td>
                          <td><?php echo number_format($bkn_staff->gaji, 2) ?></td>
                          <td style="text-align:center" width="140px">
                             <?php 
                             echo anchor(site_url('bkn_staff/read/'.$bkn_staff->nip),'<i class="fa fa-eye"></i>',array('title'=>'detail','class'=>'btn btn-sekundary btn-sm')); 
                             echo '  '; 
                             echo anchor(site_url('bkn_staff/update/'.$bkn_staff->nip),'<i class="fa fa-pencil-square-o"></i>',array('title'=>'edit','class'=>'btn btn-primary btn-sm')); 
                             echo '  '; 
                             echo anchor(site_url('bkn_staff/delete/'.$bkn_staff->nip),'<i class="fa fa-trash-o"></i>','title="delete" class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
                             ?>
                         </td>
                     </tr>
                     <?php
                 }
                 ?>
             </tbody>
         </table>
         <div class='box-body'>
          <table class="table table-bordered table-striped" id="mytable2">
            <thead>
              <tr>
                <th><center>Jumlah Pegawai</th>
                <th><center>Total Gaji</th>
                <th><center>Gaji Maksimum</th>
                <th><center>Gaji Minimum</th>
              <tr>
            </thead>
            <tbody>
                <tr>
                  <td> <center><?php echo $total_karyawan?> </td>
                  <td><center>
                    <?php 
                    foreach ($total_gaji as $tot) {
                      echo number_format($tot->juji, 2);
                    }
                    ?>
                  </td>
                  <td><center>
                    <?php 
                    foreach ($maximal_gaji as $max) {
                      echo number_format($max->maxgaj, 2);
                    }
                    ?> 
                  </td>
                  <td><center>
                    <?php 
                    foreach ($minimal_gaji as $min) {
                      echo number_format($min->mingaj, 2);
                    }
                ?>
                  </td>
                </tr>
            </tbody>
          </table>
          <br>
          <table class="table table-bordered table-striped" id="mytable2">
            <thead>
              <tr>
                <th><center>Gaji Rata-Rata</th>
                <th><center>Selisih Gaji Maks dan Min (S)</th>
                <th><center>Selisih (S) terhadap Gaji Min </th>
              <tr>
            </thead>
            <tbody>
              <tr>
                <td> <center>
                  <?php 
                  foreach ($rata2_gaji as $ragaj) {
                    echo number_format($ragaj->avggaj, 2);
                  }
                  ?>
                </td>
                <td><center>
                  <?php 
                  foreach ($selisih as $sel) {
                    echo number_format($sel->mm, 2);
                  }
                  ?>
                </td>
                <td><center>
                  <?php 
                  foreach ($selisih_terhadap_terendah as $stt) {
                    echo number_format($stt->spt, 2);
                  }
                  ?>
                </td>
              </tr>
            </tbody>

          </table>

        </div>
         <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
         <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
         <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>
    </div><!-- /.box-body -->
</div><!-- /.box -->
</div><!-- /.col -->
</div><!-- /.row -->
        </section><!-- /.content -->