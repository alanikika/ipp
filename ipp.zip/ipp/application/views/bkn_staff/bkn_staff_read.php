
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'>Bkn_staff Read</h3>
          <table class="table table-bordered">
           <tr><td>Nama Pejabat</td><td><?php echo $nama_pejabat; ?></td></tr>
           <tr><td>Biro</td><td><?php echo $biro; ?></td></tr>
           <tr><td>Jabatan</td><td><?php echo $jabatan; ?></td></tr>
           <tr><td>Fungsi</td><td><?php echo $fungsi; ?></td></tr>
           <tr><td>Gaji</td><td><?php echo $gaji; ?></td></tr>
           <tr><td>Bobot Pendidikan</td><td><?php echo ''; ?></td></tr>
           <tr><td>Bobot Pelatihan</td><td><?php echo ''; ?></td></tr>
           <tr><td>Bobot Pengalaman</td><td><?php echo ''; ?></td></tr>
           <tr><td>Bobot Diklat</td><td><?php echo ''; ?></td></tr>
           <tr><td><b>Penilaian Objektif</td><td><?php echo ''; ?></td></tr>
           <tr><td></td><td><a href="<?php echo site_url('bkn_staff') ?>" class="btn btn-default">Cancel</a></td></tr>
         </table>
       </div><!-- /.box-body -->
     </div><!-- /.box -->
   </div><!-- /.col -->
 </div><!-- /.row -->
        </section><!-- /.content -->