<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          
          <h3 class='box-title'>CREATE PELANGGARAN STAFF</h3>
          <div class='box box-primary'>
            <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
              <tr><td>NIP <?php echo form_error('nip') ?></td>
                <td><?php echo cmb_dinamis('nip', 'bkn_staff', 'nip', 'nip', 'nip') ?>
                </td>
             <tr><td>Jenis Pelanggaran <?php echo form_error('id_pelanggaran') ?></td>
              <td><?php echo cmb_dinamis('id_pelanggaran', 'bkn_pelanggaran', 'jenis_pelanggaran', 'id_pelanggaran', 'pelanggaran') ?>
              </td>
                <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
                <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
                 <a href="<?php echo site_url('bkn_pelanggaran_staff') ?>" class="btn btn-default">Cancel</a></td></tr>
                 
               </table></form>
             </div><!-- /.box-body -->
           </div><!-- /.box -->
         </div><!-- /.col -->
       </div><!-- /.row -->
        </section><!-- /.content -->