
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'>BOBOT PELANGGARAN STAFF<?php echo anchor('bkn_pelanggaran_staff/create/','Create',array('class'=>'btn btn-primary btn-sm'));?>
            <?php echo anchor(site_url('bkn_pelanggaran_staff/excel'), ' <i class="fa fa-file-excel-o"></i> Excel', 'class="btn btn-warning btn-sm"'); ?>
            <?php echo anchor(site_url('bkn_pelanggaran_staff/word'), '<i class="fa fa-file-word-o"></i> Word', 'class="btn btn-warning btn-sm"'); ?>
            <?php echo anchor(site_url('bkn_pelanggaran_staff/pdf'), '<i class="fa fa-file-pdf-o"></i> PDF', 'class="btn btn-warning btn-sm"'); ?></h3>
            <br><br>
            <body>
             <div>
             <form action=<?php echo base_url().'index.php/bkn_pelanggaran_staff' ?>>
                <select name="biro_nama">
                  <option value='' selected="selected">-----Tampilkan Biro----</option>
                  <?php foreach($biro as $biro):?>
                    <option value="<?php echo $biro->id_biro?>"><?php echo $biro->b?></option>
                  <?php endforeach;?>
                </select> &nbsp
                <button type="submit" class="btn btn-primary"><?php echo "Sort" ?></button> 
              </form>
            </div>
          </body>

          <br>
          <?php 
          foreach ($rata_pelanggaran as $rataan) {
            echo "Rata-Rata bobot pelanggaran = " . number_format($rataan->rata, 2);
          }
          ?>


        </div><!-- /.box-header -->
        <div class='box-body'>
          <table class="table table-bordered table-striped" id="mytable">
            <thead>
              <tr>
                <th width="80px">No</th>
                <th>NIP</th>
                <th>Bobot Total</th> 
                <!--<th>Bobot Pelanggaran</th> -->
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $start = 0;
              foreach ($bkn_pelanggaran_staff_data as $bkn_pelanggaran_staff)
              {
                ?>
                <tr>
                  <td><?php echo ++$start ?></td>
                  <td><?php echo $bkn_pelanggaran_staff->nip ?></td>
                  <td><?php echo $bkn_pelanggaran_staff->bobot ?></td>
                  <td style="text-align:center" width="140px">
                   <?php 
                   echo anchor(site_url('bkn_pelanggaran_staff/read/'.$bkn_pelanggaran_staff->nip),'<i class="fa fa-eye"></i>',array('title'=>'detail','class'=>'btn btn-sekundary btn-sm')); 
                   echo '  '; 
                   ?>
                 </td>

                 <?php
               }
               ?>
               <?php 

               ?>
             </tr>
           </tbody>
         </table>
         <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
         <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
         <script type="text/javascript">
          $(document).ready(function () {
            $("#mytable").dataTable();
          });
        </script>
      </div><!-- /.box-body -->
    </div><!-- /.box -->
  </div><!-- /.col -->
</div><!-- /.row -->
        </section><!-- /.content -->