
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>Bkn_task_staff Read</h3>
        <table class="table table-bordered">
	    <tr><td>Nip</td><td><?php echo $nip; ?></td></tr>
	    <tr><td>Kinerja</td><td><?php echo $kinerja; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('bkn_task_staff') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->