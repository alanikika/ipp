<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          
          <h3 class='box-title'>CREATE BIRO</h3>
          <div class='box box-primary'>
            <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
             <tr><td>Nama Biro <?php echo form_error('nama_biro') ?></td>
              <td><input type="text" class="form-control" name="nama_biro" id="nama_biro" placeholder="Nama Biro" value="<?php echo $nama_biro; ?>" />
              </td>
              <input type="hidden" name="id_biro" value="<?php echo $id_biro; ?>" /> 
              <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
               <a href="<?php echo site_url('bkn_biro') ?>" class="btn btn-default">Cancel</a></td></tr>
               
             </table></form>
           </div><!-- /.box-body -->
         </div><!-- /.box -->
       </div><!-- /.col -->
     </div><!-- /.row -->
        </section><!-- /.content -->