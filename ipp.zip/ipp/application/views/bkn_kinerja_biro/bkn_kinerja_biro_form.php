<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>

          <h3 class='box-title'>CREATE KINERJA KELAS JABATAN BY BIRO</h3>
          <div class='box box-primary'>
            <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
             <tr><td>Biro <?php echo form_error('biro') ?></td>
             <td><?php echo cmb_dinamis('biro', 'bkn_biro', 'nama_biro', 'id_biro', 'biro') ?>
              </td>
              <tr><td>Jabatan <?php echo form_error('jabatan') ?></td>
                <td><?php echo cmb_dinamis('jabatan', 'bkn_kelas_jabatan', 'nama_jabatan', 'id_jabatan', 'jabatan') ?>
                </td>
                <tr><td>Nilai Skp <?php echo form_error('nilai_skp') ?></td>
                  <td><input type="text" class="form-control" name="nilai_skp" id="nilai_skp" placeholder="Nilai Skp" value="<?php echo $nilai_skp; ?>" />
                  </td>
                  <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
                  <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
                   <a href="<?php echo site_url('bkn_kinerja_biro') ?>" class="btn btn-default">Cancel</a></td></tr>

                 </table></form>
               </div><!-- /.box-body -->
             </div><!-- /.box -->
           </div><!-- /.col -->
         </div><!-- /.row -->
        </section><!-- /.content -->