
<!-- Main content -->
<section class='content'>
  <div class='row'>
    <div class='col-xs-12'>
      <div class='box'>
        <div class='box-header'>
          <h3 class='box-title'>LIST KINERJA BIRO PER KELAS JABATAN <?php echo anchor('bkn_kinerja_biro/create/','Create',array('class'=>'btn btn-primary btn-sm'));?>
              <?php echo anchor(site_url('bkn_kinerja_biro/excel'), ' <i class="fa fa-file-excel-o"></i> Excel', 'class="btn btn-warning btn-sm"'); ?>
              <?php echo anchor(site_url('bkn_kinerja_biro/word'), '<i class="fa fa-file-word-o"></i> Word', 'class="btn btn-warning btn-sm"'); ?>
              <?php echo anchor(site_url('bkn_kinerja_biro/pdf'), '<i class="fa fa-file-pdf-o"></i> PDF', 'class="btn btn-warning btn-sm"'); ?></h3>
              <br><br>
            <body>
            <div>
              <form action=<?php echo base_url().'index.php/bkn_kinerja_biro' ?>>
                <select name="biro_nama">
                  <option value='' selected="selected">-----Tampilkan Berdasar Biro----</option>
                  <?php foreach($biro as $biro):?>
                    <option value="<?php echo $biro->id_biro?>"><?php echo $biro->b?></option>
                  <?php endforeach;?>
                </select> &nbsp
                <button type="submit" class="btn btn-primary"><?php echo "Sort" ?></button> 
              </form>
            </div>
          </body>
          </div><!-- /.box-header -->

          <div class='box-body'>
            <table class="table table-bordered table-striped" id="mytable">
                <thead>
                    <tr>
                        <th width="80px">No</th>
                        <th>Biro</th>
                        <th>Jabatan</th>
                        <th>Nilai Skp</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $start = 0;
                    foreach ($bkn_kinerja_biro_data as $bkn_kinerja_biro)
                    {
                        ?>
                        <tr>
                          <td><?php echo ++$start ?></td>
                          <td><?php echo $bkn_kinerja_biro->nama_biro ?></td>
                          <td><?php echo $bkn_kinerja_biro->nama_jabatan ?></td>
                          <td><?php echo $bkn_kinerja_biro->nilai_skp ?></td>
                          <td style="text-align:center" width="140px">
                             <!-- <?php 
                             echo anchor(site_url('bkn_kinerja_biro/read/'.$bkn_kinerja_biro->id),'<i class="fa fa-eye"></i>',array('title'=>'detail','class'=>'btn btn-sekundary btn-sm')); 
                             echo '  '; 
                             echo anchor(site_url('bkn_kinerja_biro/update/'.$bkn_kinerja_biro->id),'<i class="fa fa-pencil-square-o"></i>',array('title'=>'edit','class'=>'btn btn-primary btn-sm')); 
                             echo '  '; 
                             echo anchor(site_url('bkn_kinerja_biro/delete/'.$bkn_kinerja_biro->id),'<i class="fa fa-trash-o"></i>','title="delete" class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
                             ?> -->
                         </td>
                     </tr>
                     <?php
                 }
                 ?>
             </tbody>
         </table>
         <br>
         <table class="table table-bordered table-striped" id="mytable2">
            <thead>
              <tr>
                <th>Nilai SKP Rata-Rata</th>
              <tr>
            </thead>
                <tbody>
                  <tr>
                    <td>
                      <?php
                      foreach ($avg_kinerja_biro as $avg_kinerja_biro) {
                        echo number_format($avg_kinerja_biro->avgskp, 2);
                      }
                      ?>
                    </tr>
                  </tbody>

                </table>
         <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
         <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
         <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>
    </div><!-- /.box-body -->
</div><!-- /.box -->
</div><!-- /.col -->
</div><!-- /.row -->
        </section><!-- /.content -->