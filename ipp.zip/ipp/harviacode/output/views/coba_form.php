<!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                
                  <h3 class='box-title'>COBA</h3>
                      <div class='box box-primary'>
        <form action="<?php echo $action; ?>" method="post"><table class='table table-bordered'>
	    <tr><td>Sdsdsd <?php echo form_error('sdsdsd') ?></td>
            <td><input type="text" class="form-control" name="sdsdsd" id="sdsdsd" placeholder="Sdsdsd" value="<?php echo $sdsdsd; ?>" />
        </td>
	    <input type="hidden" name="dsdsd" value="<?php echo $dsdsd; ?>" /> 
	    <tr><td colspan='2'><button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('coba') ?>" class="btn btn-default">Cancel</a></td></tr>
	
    </table></form>
    </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->